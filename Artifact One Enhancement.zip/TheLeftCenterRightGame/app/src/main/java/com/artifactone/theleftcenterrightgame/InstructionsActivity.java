// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: When the user taps the "Instructions" button on the home screen in
// the MainActivity, they will be presented the rules of playing LCR. This program
// reads the instructions from an external file and allows the user the option to
// scroll down in order to read more. This file contains all the code required for
// this task to be accomplished.
// ***Directly corresponds to the ReadInstructions method in the original C++ version***
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;

public class InstructionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.instructions);

        // Link the text file to the TextView in the xml file.
        TextView mDisplayedText = findViewById(R.id.displayedInstructions);

        // Call the function that reads from an external text file.
        // Display the text on the screen for users to read.
        String mInstructionsText = readFile();
        mDisplayedText.setText(mInstructionsText);
    }

    // This function allows us to read from a file that contains instructions
    // on how to play the Left Center Right game.
    private String readFile()
    {
       // Declare String variable to hold the text from the external file.
       String instructions = "";

       // Read from the instructions text file within the assets folder.
       // Ensure exceptions are caught so program doesn't break.
       try {
           InputStream stream = getAssets().open("LCR_text_instructions.txt");
           byte[] buffer = new byte[11000];
           stream.read(buffer);
           stream.close();
           instructions = new String(buffer);
       }
       catch (IOException e) {
           e.printStackTrace();
       }

        // Display instructions on the screen through xml file.
        return instructions;
    }
}