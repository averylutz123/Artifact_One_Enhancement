// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This activity calculates the number of rolls allotted to each player during
// their turn. This value is based on the number of chips in the player's possession.
// **Directly corresponds to the CalculateRolls method in the original C++ version.
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------
package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class CalculateRollsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_rolls);

        // Link widgets to their functional components in this activity.
        TextView mNumberOfRollsText = findViewById(R.id.numberOfRollsText);
        TextView mPlayerNameText = findViewById(R.id.currentPlayerTurnText);
        Button mRollButton = findViewById(R.id.rollButton);
        String numberOfRollsString;

        // Random value to display diverse text dialog.
        Random random = new Random();
        int response = random.nextInt(3) + 1;

        ////// Passed In Values /////
        Intent intent = getIntent();

        // Number of players.
        String mNumberOfPlayersString = intent.getStringExtra("numberOfPlayers");
        int mNumberOfPlayers = Integer.parseInt(mNumberOfPlayersString);

        // Total number of chips that will be tracked.
        String mTotalChipsString = intent.getStringExtra("totalChipString");

        // Current player value.
        String mCurrentPlayerString = intent.getStringExtra("currentPlayer");
        int mCurrentPlayer = Integer.parseInt(mCurrentPlayerString);

        // The point's array and name's array.
        int[] pointTrackerArray = intent.getIntArrayExtra("pointList");
        String[] nameArray = intent.getStringArrayExtra("nameList");
        ////// Passed In Values /////

        // Create a String Buffer to hold the text that will be displayed.
        StringBuffer nameIntroText = new StringBuffer();
        nameIntroText.append(nameArray[mCurrentPlayer]).append("...");
        mPlayerNameText.setText(nameIntroText);

        // Send players with no chips back to the scoreboard.
        // Use diverse dialog options.
        if (pointTrackerArray[mCurrentPlayer] == 0){
            if (response == 1) {
                mNumberOfRollsText.setText(R.string.noCoins);
            }
            else if (response == 2){
                mNumberOfRollsText.setText(R.string.noCoinsSecond);
            }
            else {
                mNumberOfRollsText.setText(R.string.noCoinsThird);
            }
            mRollButton.setText(R.string.skipTurnButton);

            // Move to the next player in the list. Account for last player in array.
            if (mCurrentPlayer == (mNumberOfPlayers - 1)){
                mCurrentPlayer = 0;
            }
            else{
                mCurrentPlayer++;
            }
            String mCurrentPlayerStringReturn = String.valueOf(mCurrentPlayer);

            // Activate the roll button that sends users back to the scoreboard.
            mRollButton.setOnClickListener(view -> {
                Intent intentTwo = new Intent(getApplicationContext(), ScoresActivity.class);
                intentTwo.putExtra("numberOfPlayers", mNumberOfPlayersString);
                intentTwo.putExtra("totalChipsString", mTotalChipsString);
                intentTwo.putExtra("currentPlayer",mCurrentPlayerStringReturn);
                intentTwo.putExtra("pointList", pointTrackerArray);
                intentTwo.putExtra("nameList", nameArray);
                startActivity(intentTwo);
            });
        }

        // Inform the users how many rolls they are allotted.
        // Diversify the response to make the game more interesting.
        else {
            mRollButton.setText(R.string.rollButton);
            if (pointTrackerArray[mCurrentPlayer] == 1) {
                if (response == 1) {
                    mNumberOfRollsText.setText(R.string.oneCoin);
                }
                else if (response == 2) {
                    mNumberOfRollsText.setText(R.string.oneCoinSecond);
                }
                else  {
                    mNumberOfRollsText.setText(R.string.oneCoinThird);
                }
                numberOfRollsString = "1";
            }
            else if (pointTrackerArray[mCurrentPlayer] == 2) {
                if (response == 1) {
                    mNumberOfRollsText.setText(R.string.twoCoins);
                }
                else if (response == 2) {
                    mNumberOfRollsText.setText(R.string.twoCoinsSecond);
                }
                else {
                    mNumberOfRollsText.setText(R.string.twoCoinsThird);
                }
                numberOfRollsString = "2";
            }
            else {
                if (response == 1) {
                    mNumberOfRollsText.setText(R.string.threeCoins);
                }
                else if (response == 2) {
                    mNumberOfRollsText.setText(R.string.threeCoinsSecond);
                }
                else{
                    mNumberOfRollsText.setText(R.string.threeCoinsThird);
                }
                numberOfRollsString = "3";
            }

            // Activate the roll button that sends users to the Game Play Activity.
            mRollButton.setOnClickListener(view -> {
                Intent intentTwo = new Intent(getApplicationContext(), GamePlayActivity.class);
                intentTwo.putExtra("numberOfPlayers", mNumberOfPlayersString);
                intentTwo.putExtra("totalChipsString", mTotalChipsString);
                intentTwo.putExtra("currentPlayer",mCurrentPlayerString);
                intentTwo.putExtra("pointList", pointTrackerArray);
                intentTwo.putExtra("nameList", nameArray);
                intentTwo.putExtra("numberOfRollsString", numberOfRollsString);
                startActivity(intentTwo);
            });
        }
    }
}