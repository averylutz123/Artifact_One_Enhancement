// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This file displays the directions on how each player should be sitting next to
// one another. This activity did not exist in the original version of the program, but it
// seemed beneficial to inform the players as to how the game interpreted "left" & "right."
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class OrderActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        // Link necessary variables with corresponding widgets in the xml file.
        TextView mOrderTextView = findViewById(R.id.PassingDirections);
        Button mLetsPlayButton = findViewById(R.id.LetsPlayButton);

        // Number of players.
        Intent intent = getIntent();
        String mNumberOfPlayersString = intent.getStringExtra("numberOfPlayers");
        int mNumberOfPlayers = Integer.parseInt(mNumberOfPlayersString);

        // The point's array and name's array.
        int[] pointTrackerArray = intent.getIntArrayExtra("pointList");
        String[] nameArray = intent.getStringArrayExtra("nameList");

        // Initialize value to represent the current player & the total number of chips.
        String mCurrentPlayerString = "0";
        int totalChips = (3 * mNumberOfPlayers);
        String totalChipsString = String.valueOf(totalChips);

        StringBuilder orderText = new StringBuilder();

        // Loop through each element in the name array to inform the players as to who should
        // be sitting next to one another. The current element (i) represents the player being
        // addressed. The previous element (i-1) represents the player to their left and the
        // following element (i+1) represents the player to their right.
        for (int i = 0; i < mNumberOfPlayers; i++) {
            if (i == 0) {
                orderText.append(nameArray[i]).append(", you should have ").append(nameArray[i + 1])
                        .append(" to your right and ").append(nameArray[mNumberOfPlayers - 1])
                        .append(" to your left.").append("\n\n");
            }
            else if (i == (mNumberOfPlayers-1)){
                orderText.append(nameArray[i]).append(", you should have ").append(nameArray[0])
                        .append(" to your right and ").append(nameArray[i - 1])
                        .append(" to your left.").append("\n\n");
            }
            else{
                orderText.append(nameArray[i]).append(", you should have ").append(nameArray[i + 1])
                        .append(" to your right and ").append(nameArray[i - 1])
                        .append(" to your left.").append("\n\n");
            }
        }
        mOrderTextView.setText(orderText + "\n\n\n\n");


        // Activate Let's Play button so that users can continue to the
        // next screen and they can start the game.
        mLetsPlayButton.setOnClickListener(view -> {
            Intent intentTwo = new Intent(getApplicationContext(), ScoresActivity.class);
            intentTwo.putExtra("numberOfPlayers", mNumberOfPlayersString);
            intentTwo.putExtra("totalChipsString", totalChipsString);
            intentTwo.putExtra("currentPlayer",mCurrentPlayerString);
            intentTwo.putExtra("pointList", pointTrackerArray);
            intentTwo.putExtra("nameList", nameArray);
            startActivity(intentTwo);
        });
    }
}