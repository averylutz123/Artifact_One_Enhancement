// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This file contains the screen in which users will enter the names of the
// players who will be participating in the game. Names are displayed once user enters
// their name and presses the "add" button. Users can input names until we reach the
// count for the total number of players
// ****Directly corresponds to the askPlayerNames method in the original C++ version****
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class PlayerNamesActivity extends AppCompatActivity {

    // Initialize this counting variable so that we can control
    // the number of player names that are entered.
    private int y = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_names);

        // Link interactive features with corresponding widgets in the xml file.
        Button mAddButton = findViewById(R.id.addButton);
        Button mReadyButton = findViewById(R.id.readyButton);
        EditText mNamesEditText = findViewById(R.id.addNameText);
        TextView mNameTextView = findViewById(R.id.nameList);

        // Number of players.
        Intent intent = getIntent();
        String mNumberOfPlayersString = intent.getStringExtra("numberOfPlayers");
        int mNumberOfPlayers = Integer.parseInt(mNumberOfPlayersString);

        // Create an array to store the game points.
        // Assign each element in the array a value of 3.
        int[] pointTrackerArray = new int[mNumberOfPlayers];
        for (int i = 0; i < mNumberOfPlayers; ++i) {
            pointTrackerArray[i] = 3;
        }

        // Create an array that will store the names of each player.
        String [] nameArray = new String[mNumberOfPlayers];
        for (int i = 0; i < mNumberOfPlayers; ++i) {
            nameArray[i] = " ";
        }

        // Do not allow users to continue playing until all names are entered.
        if (y < mNumberOfPlayers) {
            mReadyButton.setEnabled(false);
        }

        // Activate Add button so user can input names.
        mAddButton.setOnClickListener(view -> {

            // Ignore any leading or trailing spaces.
            String name = mNamesEditText.getText().toString().trim();

            // Clear the EditText so it's ready for another item.
            mNamesEditText.setText("");

            // Ensure that users cannot enter more names than players.
            if (y >= mNumberOfPlayers){
                new AlertDialog.Builder(this)
                        .setTitle(R.string.playerNamesWarning)
                        .setMessage(R.string.playerNamesMessage)
                        .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                        .create().show();
            }

            // Add the item to the list and display the list of names entered.
            // Once all players are entered, the user can press the Ready button.
                if (name.length() > 0 && y < mNumberOfPlayers ) {
                    StringBuffer nameText = new StringBuffer();
                    nameArray[y] = name;
                    for (int i = 0; i < y + 1; i++) {
                        nameText.append("Player ").append(i + 1).append(". ").append(nameArray[i]).append("\n");
                        mNameTextView.setText(nameText);
                    }
                    ++ y;
                    if (y >= mNumberOfPlayers && mNumberOfPlayers >= 10){
                        nameText.append("\n\n");
                        mNameTextView.setText(nameText);
                    }
                    if (y >= mNumberOfPlayers){
                        mReadyButton.setEnabled(true);
                    }
                }
        });

        // Activate Let's Play button that can only be pressed when
        // all players are entered. We also must begin passing values
        // between the different activities.
        mReadyButton.setOnClickListener(view -> {
            Intent intentTwo = new Intent(getApplicationContext(), OrderActivity.class);
            intentTwo.putExtra("nameList", nameArray);
            intentTwo.putExtra("pointList", pointTrackerArray);
            intentTwo.putExtra("numberOfPlayers", mNumberOfPlayersString);
            startActivity(intentTwo);
        });
    }
}