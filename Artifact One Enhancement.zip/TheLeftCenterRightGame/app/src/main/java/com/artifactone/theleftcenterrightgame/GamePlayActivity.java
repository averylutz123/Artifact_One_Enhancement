// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This activity "rolls the dice" for the players and displays the results of
// each roll. This activity also changes the players' scores within the points array. All
// components related to having a functional game exist within this section of the program.
// *Corresponds to the rollTheDie, directionOfPass, gamePlay, and isThereAWinner methods
// in the C++ version*
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class GamePlayActivity extends AppCompatActivity {

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_play);

        // Declare variables required in the main program method.
        int dieValue;
        char direction;
        String response;
        Drawable imageOfDice;
        String winner;

        // Link widgets to their functional components in this activity.
        TextView mRollInformationText = findViewById(R.id.RollInformationText);
        Button mContinueButton = findViewById(R.id.ContinueButton);
        ImageView mFirstRollImage = findViewById(R.id.firstRollImage);
        ImageView mSecondRollImage = findViewById(R.id.secondRollImage);
        ImageView mThirdRollImage = findViewById(R.id.thirdRollImage);

        ////// Passed In Values /////
        Intent intent = getIntent();

        // Number of players.
        String mNumberOfPlayersString = intent.getStringExtra("numberOfPlayers");
        int mNumberOfPlayers = Integer.parseInt(mNumberOfPlayersString);

        // Total number of chips that will be tracked.
        String mTotalChipsString = intent.getStringExtra("totalChipsString");
        int mTotalChips = Integer.parseInt(mTotalChipsString);

        // Current player value.
        String mCurrentPlayerString = intent.getStringExtra("currentPlayer");
        int mCurrentPlayer = Integer.parseInt(mCurrentPlayerString);

        // The point's array and name's array.
        int[] pointTrackerArray = intent.getIntArrayExtra("pointList");
        String[] nameArray = intent.getStringArrayExtra("nameList");

        // Number of permitted rolls.
        String mNumberOfRollsString = intent.getStringExtra("numberOfRollsString");
        int mNumberOfRolls = Integer.parseInt(mNumberOfRollsString);
        ////// Passed In Values /////

        // Create a stringBuffer to display text to the xml screen.
        StringBuffer directionOfDieText = new StringBuffer();

        // Main for loop of the program. Most gameplay mechanics are here.
        for (int i = 0; i < mNumberOfRolls; i++) {

            dieValue = rollTheDie();                    // Determine value that the die rolled.
            imageOfDice = displayDieImage(dieValue);     // Determine what image to display.

            // List which roll the player is on & display a corresponding image.
            if (i == 0) {
                directionOfDieText.append("Roll One:").append("\n");
                mFirstRollImage.setImageDrawable(imageOfDice);
            }
            else if (i == 1) {
                directionOfDieText.append("Roll Two:").append("\n");
                mSecondRollImage.setImageDrawable(imageOfDice);
            }
            else if (i == 2) {
                directionOfDieText.append("Roll Three:").append("\n");
                mThirdRollImage.setImageDrawable(imageOfDice);
            }

            // Determine the direction that chips will be passed and
            // the response that will be told to the users.
            direction = directionOfPass(dieValue);
            response = responseForDirection(direction, dieValue);
            directionOfDieText.append(response).append("\n\n");
            pointTrackerArray = coinPass(pointTrackerArray, mCurrentPlayer, mNumberOfPlayers, direction);

            // Rolling a 3 (C) is the only option that affects the total of chips.
            if (direction == 'C'){
                mTotalChips = mTotalChips - 1;
            }
        }
        
        mRollInformationText.setText(directionOfDieText);
        winner = isThereAWinner(pointTrackerArray, mTotalChips, nameArray);

        // Move to the next player in the list. Account for last player.
        if (mCurrentPlayer == (mNumberOfPlayers - 1)){
            mCurrentPlayer = 0;
        }
        else{
            mCurrentPlayer++;
        }

        String mCurrentPlayerStringReturn = String.valueOf(mCurrentPlayer);
        int[] finalPointTrackerArray = pointTrackerArray;

        String mTotalChipReturn = String.valueOf(mTotalChips);

        // If the result of the isThereAWInner method is anything besides "None,"
        // a winner is selected and sent to the winner screen.
        if (!winner.equals("None")){
            mContinueButton.setOnClickListener(view -> {
                Intent intentThree = new Intent(getApplicationContext(), WinnerActivity.class);
                intentThree.putExtra("winner", winner);
                startActivity(intentThree);
            });
        }
        else{
            mContinueButton.setOnClickListener(view -> {
                Intent intentTwo = new Intent(getApplicationContext(), ScoresActivity.class);
                intentTwo.putExtra("numberOfPlayers", mNumberOfPlayersString);
                intentTwo.putExtra("totalChipsString", mTotalChipReturn);
                intentTwo.putExtra("currentPlayer",mCurrentPlayerStringReturn);
                intentTwo.putExtra("pointList", finalPointTrackerArray);
                intentTwo.putExtra("nameList", nameArray);
                startActivity(intentTwo);
            });
        }
    }
/////////////////////////////////END OF ON CREATE FUNCTION////////////////////////////////


    ///////////////// Function that randomly generates a die value ///////////////////////
    int rollTheDie(){
        Random random = new Random();
        return random.nextInt(6) + 1;
    }


    ///////////// Function that selects the correct die image to display. /////////////////
    @SuppressLint("UseCompatLoadingForDrawables")
    Drawable displayDieImage(int dieValue){

        // Based on the given die value, display a corresponding image.
        Drawable imageOfDice;
        if (dieValue == 1){
            imageOfDice = getResources().getDrawable(R.drawable.rolled_one);
        }
        else if (dieValue == 2){
            imageOfDice = getResources().getDrawable(R.drawable.rolled_two);
        }
        else if (dieValue == 3){
            imageOfDice = getResources().getDrawable(R.drawable.rolled_three);
        }
        else if (dieValue == 4){
            imageOfDice = getResources().getDrawable(R.drawable.rolled_four);
        }
        else if (dieValue == 5){
            imageOfDice = getResources().getDrawable(R.drawable.rolled_five);
        }
        else {
            imageOfDice = getResources().getDrawable(R.drawable.rolled_six);
        }
        return imageOfDice;
    }


    ////////////// Function that determines the direction of the coin pass ///////////////
    char directionOfPass(int dieValue){
        char direction;

        if (dieValue == 1){
            direction = 'L';              // Player passes coin to the left.
        }
        else if (dieValue == 2){
            direction = 'R';              // Player passes coin to the right.
        }
        else if (dieValue == 3){
            direction = 'C';              // Player puts coin in the center pot.
        }
        else{
            direction = '*';              // Player keeps their coin.
        }

        return direction;
    }


    /////////////// Function that passes coins and completes gameplay ////////////////////
    int[] coinPass (int[] pointTrackerArray, int mCurrentPlayer, int mNumberOfPlayers, char direction){

        // With every option, except "*", the player loses a coin.
        if (direction != '*'){
            pointTrackerArray[mCurrentPlayer] = pointTrackerArray[mCurrentPlayer] - 1;

            // Player passes a coin to their left. Accounts for first player in array.
            if (direction == 'L'){
                if (mCurrentPlayer == 0) {
                    pointTrackerArray[mNumberOfPlayers - 1] = pointTrackerArray[mNumberOfPlayers - 1] + 1;
                }
                else {
                    pointTrackerArray[mCurrentPlayer - 1] = pointTrackerArray[mCurrentPlayer - 1] + 1;
                }
            }
            // Player passes a coin to their right. Accounts for last player in array.
            else if (direction == 'R') {
                if (mCurrentPlayer == (mNumberOfPlayers - 1)) {
                    pointTrackerArray[0] = pointTrackerArray[0] + 1;
                }
                else {
                    pointTrackerArray[mCurrentPlayer + 1] = pointTrackerArray[mCurrentPlayer + 1] + 1;
                }
            }
        }
        // Return the recalculated point system.
        return pointTrackerArray;
    }


    ///////////////// Function that provides response about coin direction ////////////////
    String responseForDirection(char direction, int dieValue){

        String response = "";
        String dieValueString;

        // Based on the value the player rolled, we inform the user which direction
        // they must pass their chips.
        if (direction == 'L'){
            response = "You rolled a one, please pass one coin to your left.";
        }
        else if (direction == 'R'){
            response = "You rolled a two, please pass one coin to your right.";
        }
        else if (direction == 'C'){
            response = "You rolled a three, please put one coin in the center pot.";
        }
        else if (direction == '*'){                     // Ensure the rolls of 4, 5, and 6 are
            if (dieValue == 4){                         // displayed in word form so the formatting
                dieValueString = "four";                // is consistent.
            }
            else if (dieValue == 5){
                dieValueString = "five";
            }
            else{
                dieValueString = "six";
            }
            response = "You rolled a " + dieValueString + ", thus no action is required.";
        }
        return response;
    }


    /////////////////////// Function that returns the winner's name ////////////////////
    String isThereAWinner(int[] pointTrackerArray, int mTotalChips, String[] nameArray){
        String winner = "None";

        // If one user obtains all playable chips, they win.
        for (int i = 0; i < pointTrackerArray.length; ++i) {
            if(pointTrackerArray[i] == mTotalChips){
                winner = nameArray[i];
            }
        }
        return winner;
    }
}