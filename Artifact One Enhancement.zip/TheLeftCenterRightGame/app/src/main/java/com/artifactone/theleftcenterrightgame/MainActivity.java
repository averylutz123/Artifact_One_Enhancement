// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This file is associated with the "home screen" that users are greeted with
// when they first open the app. Users are presented three buttons that they can tap to
// continue to a different screen. The instructions button takes them to a screen that
// displays the rules of the game. The about button takes them to a screen that shares
// details as to why this game was created and goals of the artifact one capstone. The
// play button sends users into the game. This activity acts as the intersection from
// the home screen to the "other side" of the user selecting one of the three buttons.
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declare variables used throughout this program and link them
        // to the corresponding button in the activity_main xml file.
        Button mInstructionsButton = findViewById(R.id.InstructionsButton);
        Button mAboutButton = findViewById(R.id.AboutButton);
        Button mPlayButton = findViewById(R.id.PlayButton);

        // Activate Instructions button on Introduction screen.
        mInstructionsButton.setOnClickListener(view -> {
            // Display toast message & go to the Instructions screen (InstructionsActivity).
            Toast.makeText(MainActivity.this, R.string.welcomeToast, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), InstructionsActivity.class);
            startActivity(intent);
        });

        // Activate About button on Introduction screen.
        mAboutButton.setOnClickListener(view -> {
            // Display toast message & go to the About screen (AboutActivity).
            Toast.makeText(MainActivity.this, R.string.letsLearn, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
            startActivity(intent);
        });

        // Activate Play button on Introduction screen.
        mPlayButton.setOnClickListener(view -> {
            // Display toast message & go to the Number of Players screen (NumberOfPlayersActivity).
            Toast.makeText(MainActivity.this, R.string.letsPlay, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), NumberOfPlayersActivity.class);
            startActivity(intent);
        });
    }
}