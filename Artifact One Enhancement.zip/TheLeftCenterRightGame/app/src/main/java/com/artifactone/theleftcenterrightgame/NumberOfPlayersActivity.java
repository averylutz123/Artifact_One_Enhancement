// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This file contains the screen in which users will enter the number of players
// who will be participating within the game. The user must enter a value of at least
// three in order to continue or else they will be prevented from moving on. Additionally,
// a message will appear correcting the user when they enter an unaccepted value.
// ****Directly corresponds to the askPlayerNumber method in the original C++ version****
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NumberOfPlayersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number_of_players);

        // Link Button and EditText variables with widgets in the xml file.
        Button mEnterButton = findViewById(R.id.enterNumberButton);
        EditText mUserInput = findViewById(R.id.userEnteredNumber);


        // Activate Enter button so the user can submit their input.
        mEnterButton.setOnClickListener(view -> {
            String mUserInputString = mUserInput.getText().toString();
            int mNumberOfPlayers = Integer.parseInt(mUserInputString);

            // The game requires a minimum of three players.
            // Check the user's input & don't continue without an appropriate value.
            if (mNumberOfPlayers < 3) {

                // Inform the user when they enter an unaccepted value that is too low.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.alertMessageTitle)
                        .setMessage(R.string.numberOfPlayerMessage)
                        .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                        .create().show();
            }
            else if (mNumberOfPlayers > 30) {

                // Inform the user when they enter an unaccepted value that is too high.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.alertMessageTitle)
                        .setMessage(R.string.tooManyPeople)
                        .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                        .create().show();
            }
            // When a value greater than or equal to three is entered, the game continues.
            // Send user to PlayerNamesActivity to enter the names of each player.
            else {
                Toast.makeText(NumberOfPlayersActivity.this, R.string.whosePlaying, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), PlayerNamesActivity.class);
                intent.putExtra("numberOfPlayers", mUserInputString);
                startActivity(intent);
            }
        });
    }
}

