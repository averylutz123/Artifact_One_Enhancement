// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: When the user taps the "About" button on the home screen in
// the MainActivity, they will be presented information regarding the creation and
// general purpose of the game. This information will be read into the program via an
// external text file similar to the instructions of the program.
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // We link the text file to the TextView in the xml file.
        TextView mAboutGameText = findViewById(R.id.displayedAbout);

        // Call the function that reads from an external text file.
        // Display the text on the screen for users to read.
        String mAboutText = readFile();
        mAboutGameText.setText(mAboutText);
    }

    // This function reads from a file that contains information about
    // the creation of the Left Center Right game.
    private String readFile()
    {
        // Declare String to hold the text from the external file.
        String about = "";

        // Read from the "about game" text file in the assets folder.
        // Ensure exceptions are caught so program doesn't break.
        try {
            InputStream stream = getAssets().open("LCR_about_game.txt");
            byte[] buffer = new byte[3000];
            stream.read(buffer);
            stream.close();
            about = new String(buffer);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        // Display information on the screen through xml file.
        return about;
    }
}
