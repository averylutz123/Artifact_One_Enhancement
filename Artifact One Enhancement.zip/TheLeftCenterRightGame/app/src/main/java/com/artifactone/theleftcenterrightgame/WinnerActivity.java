// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This activity displays the name of the winner of the game. This name is passed
// in from the gamePlayActivity.
// ***Directly corresponds to the isThereAWinner method in the original C++ version***
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------
package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class WinnerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        TextView mWinnerText = findViewById(R.id.winnertext);

        // Obtain the name of the winner.
        Intent intent = getIntent();
        String mWinner= intent.getStringExtra("winner");

        // Display the name of the winner.
        mWinnerText.setText(mWinner);

    }
}