// --------------------------------------------------------------------------------------
// Created by: Avery Lutz
// Purpose: This activity displays the scores of each player before continuing the next
// turn in the game. These scores are displayed after each roll, so that players can
// understanding their current standings.
// ***Directly corresponds to the RunGame method's for loop in the original C++ version***
// CS-499 Capstone: Artifact One.
// --------------------------------------------------------------------------------------

package com.artifactone.theleftcenterrightgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ScoresActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);

        // Link widgets to activity in this program.
        TextView mScoresPerPlayerTextView = findViewById(R.id.ScoresPerPlayer);
        TextView mPlayerScoreTextView = findViewById(R.id.PlayerScores);
        Button mContinueButton = findViewById(R.id.continueButton);

        ///////////////////////// Passed In Values //////////////////////////
        // Pass the values for the number of players in from OrderActivity.
        Intent intent = getIntent();
        String mNumberOfPlayersString = intent.getStringExtra("numberOfPlayers");
        int mNumberOfPlayers = Integer.parseInt(mNumberOfPlayersString);

        // Total number of chips.
        String mTotalChipsString = intent.getStringExtra("totalChipsString");

        // Tracking value to represent current player.
        String mCurrentPlayerString = intent.getStringExtra("currentPlayer");

        // Both the point array and players' names array.
        int[] pointTrackerArray = intent.getIntArrayExtra("pointList");
        String[] nameArray = intent.getStringArrayExtra("nameList");
        ////////////////////////////Passed In Values/////////////////////////////

        // StringBuffer allows each string of a player's name
        // to be entered & displayed in the correct order.
        StringBuffer scoresText = new StringBuffer();
        for(int i = 0; i < mNumberOfPlayers; i++){
            scoresText.append(i + 1).append(".) ").append(nameArray[i]).append("\n");
        }
        // An extra space at the end of the list so that all text can be read clearly.
        scoresText.append("\n\n");
        mScoresPerPlayerTextView.setText(scoresText);

        // Follow the same StringBuffer Steps to display each player's score.
        StringBuffer scoresValueText = new StringBuffer();
        for(int i = 0; i < mNumberOfPlayers; i++){
            scoresValueText.append(pointTrackerArray[i]).append("\n");
        }

        // Format to make screen look nicer & display content.
        scoresValueText.append("\n\n\n");
        mPlayerScoreTextView.setText(scoresValueText);

        // Activate continue button to go calculate allotted rolls.
        // Pass values that will be required to calculate & coll.
        mContinueButton.setOnClickListener(view -> {
            Intent intentThree = new Intent(getApplicationContext(), CalculateRollsActivity.class);
            intentThree.putExtra("nameList", nameArray);
            intentThree.putExtra("pointList", pointTrackerArray);
            intentThree.putExtra("numberOfPlayers", mNumberOfPlayersString);
            intentThree.putExtra("currentPlayer",mCurrentPlayerString );
            intentThree.putExtra("totalChipString",mTotalChipsString);
            startActivity(intentThree);
        });
    }
}